#!/usr/bin/env python3
"""Apply Phase 2 changes to the current CTF agent checkout (fail-closed).

Edits are staged and all anchors checked before any repository file changes.
This script does not commit, push, modify historical results, or read flags.
"""

from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent


def replace_once(source, old, new, filename):
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f"{filename}: expected one matching patch anchor, found {count}")
    return source.replace(old, new, 1)


def patch_controller(source):
    source = replace_once(
        source,
        "from ctf_tools import inspect_binary, disassemble_binary\n",
        "from ctf_tools import inspect_binary, disassemble_binary\n"
        "from ctf_specialist_tools import SPECIALIST_TOOL_NAMES, execute_specialist_tool\n",
        "controller.py",
    )
    source = replace_once(
        source,
        '        try:\n            if name == "inspect_binary":\n',
        '        try:\n'
        '            if name in SPECIALIST_TOOL_NAMES:\n'
        '                return execute_specialist_tool(\n'
        '                    name, args, self.solver, self._safe_path,\n'
        '                    timeout_s=timeout_s,\n'
        '                )\n'
        '            if name == "inspect_binary":\n',
        "controller.py",
    )
    return source


def patch_agent(source):
    strategy = (
        "CATEGORY-SPECIFIC TOOLS:\n"
        "- Begin with list_files on /challenge if the available files are unclear.\n"
        "- Crypto/misc: use run_python for bounded Python scripts; Crypto,\n"
        "  sympy, z3 and pwntools are installed only in the tool image.\n"
        "- Reverse/pwn: use inspect_binary, then targeted disassemble_binary.\n"
        "- Forensics/misc: use analyze_artifact for hashes, metadata,\n"
        "  hexadecimal bytes, printable strings, and archive listings.\n"
        "- Web: HTTP access is disabled unless an authorized target network\n"
        "  is explicitly configured by the trusted controller.\n"
        "- If a tool reports an error, diagnose it before retrying.\n"
        "- Never search for benchmark solutions or expected flags.\n"
        "\n"
    )
    return replace_once(
        source, "SOLVING STRATEGY:\n",
        strategy + "SOLVING STRATEGY:\n",
        "agent_core.py",
    )


def patch_benchmark(source):
    source = replace_once(
        source,
        "from solver_runtime import DockerSolver\n",
        "from solver_runtime import DockerSolver\n"
        "from ctf_runtime_config import limits_from_env\n",
        "benchmark_runner.py",
    )
    return replace_once(
        source,
        "MAX_STEPS = 15\nMAX_SECONDS = 300\n",
        "MAX_STEPS, MAX_SECONDS = limits_from_env()\n",
        "benchmark_runner.py",
    )


def patch_challenge(source):
    source = replace_once(
        source,
        "from controller import ToolDispatcher\n",
        "from controller import ToolDispatcher\n"
        "from ctf_runtime_config import limits_from_env\n",
        "challenge_runner.py",
    )
    source = replace_once(
        source,
        "    tools = json.loads(TOOLS_FILE.read_text())\n",
        "    tools = json.loads(TOOLS_FILE.read_text())\n"
        "    dev_steps, dev_seconds = limits_from_env()\n",
        "challenge_runner.py",
    )
    source = replace_once(
        source,
        "                max_steps=15,\n                max_seconds=300",
        "                max_steps=dev_steps,\n                max_seconds=dev_seconds",
        "challenge_runner.py",
    )
    return source


def patch_run_dev(source):
    source = replace_once(
        source,
        "from controller import ToolDispatcher\n",
        "from controller import ToolDispatcher\n"
        "from ctf_runtime_config import limits_from_env\n",
        "run_dev.py",
    )
    source = replace_once(
        source,
        '    "finish"\n}',
        '    "finish",\n'
        '    "list_files",\n'
        '    "run_python",\n'
        '    "analyze_artifact",\n'
        '    "inspect_binary",\n'
        '    "disassemble_binary"\n}',
        "run_dev.py",
    )
    source = replace_once(
        source,
        "# Starts fresh isolated solver\n",
        "dev_steps, dev_seconds = limits_from_env()\n"
        "\n# Starts fresh isolated solver\n",
        "run_dev.py",
    )
    source = replace_once(
        source,
        "        max_steps=15,\n        max_seconds=300",
        "        max_steps=dev_steps,\n        max_seconds=dev_seconds",
        "run_dev.py",
    )
    return source


SPECIALIST_DEFINITIONS = [
    {
        "type": "function", "function": {
            "name": "list_files",
            "description": (
                "List up to 80 regular files, to depth 3, in /challenge "
                "(read-only contestant files) or /work (scratch scripts). "
                "Use early when file inventory is unclear."
            ),
            "parameters": {
                "type": "object", "properties": {
                    "root": {"type": "string", "enum": ["/challenge", "/work"],
                             "description": "Directory to enumerate; defaults to /challenge"}
                }, "required": [], "additionalProperties": False,
            },
        },
    },
    {
        "type": "function", "function": {
            "name": "run_python",
            "description": (
                "Run a short Python script in the isolated solver, not the controller. "
                "Crypto, sympy, z3, pwntools and other installed libraries can be imported. "
                "Maximum 2700 UTF-8 bytes; for longer scripts use write_file + run_command. "
                "Returns stdout, stderr, exit code, timeout and truncation status."
            ),
            "parameters": {
                "type": "object", "properties": {
                    "code": {"type": "string", "maxLength": 2700,
                             "description": "Python source code; print findings for the next step"},
                }, "required": ["code"], "additionalProperties": False,
            },
        },
    },
    {
        "type": "function", "function": {
            "name": "analyze_artifact",
            "description": (
                "Read-only analysis of a contestant artifact in /challenge or /work. "
                "Modes: overview (type, SHA256, metadata), hex (first 512 bytes), "
                "strings (bounded printable strings), archive (bounded 7z listing). "
                "Rejects symlinks and files >200 MiB. Never extracts untrusted archives."
            ),
            "parameters": {
                "type": "object", "properties": {
                    "path": {"type": "string", "description": "Absolute artifact path"},
                    "mode": {"type": "string", "enum": ["overview", "hex", "strings", "archive"],
                             "description": "Inspection mode; defaults to overview"},
                }, "required": ["path"], "additionalProperties": False,
            },
        },
    },
]


def patch_tool_list(content):
    obj = json.loads(content)
    if not isinstance(obj, list):
        raise RuntimeError("tools.json: expected a list")
    names = {t["function"]["name"] for t in obj}
    new_names = {t["function"]["name"] for t in SPECIALIST_DEFINITIONS}
    if names.intersection(new_names):
        raise RuntimeError("tools.json already contains a Phase 2 tool")
    obj.extend(SPECIALIST_DEFINITIONS)
    return json.dumps(obj, indent=2) + "\n"


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python patch_phase2.py /workspaces/ML-CTF-Agent_v1")
    root = Path(sys.argv[1]).resolve(strict=True)
    if not (root / ".git").exists():
        raise RuntimeError(f"Not a Git checkout: {root}")
    # Reject double applications or conflicting file names.
    additions = ("ctf_specialist_tools.py", "ctf_runtime_config.py", "test_specialist_tools.py")
    for filename in additions:
        if (root / filename).exists():
            raise RuntimeError(f"Refusing to overwrite existing {filename}")
    patches = {
        "controller.py": patch_controller,
        "agent_core.py": patch_agent,
        "benchmark_runner.py": patch_benchmark,
        "challenge_runner.py": patch_challenge,
        "run_dev.py": patch_run_dev,
        "tools.json": patch_tool_list,
    }
    staged = {}
    for filename, change in patches.items():
        original = (root / filename).read_text(encoding="utf-8")
        altered = change(original)
        if filename.endswith(".py"):
            compile(altered, filename, "exec")
        staged[filename] = altered

    # No files are changed until every anchor and syntax check succeeds.
    for filename, content in staged.items():
        (root / filename).write_text(content, encoding="utf-8")
    for filename in additions:
        shutil.copy2(HERE / filename, root / filename)
    print("Phase 2 installed. Previous project behavior remains default.")
    print("No git commit, push, API call, or benchmark run was performed.")


if __name__ == "__main__":
    main()
