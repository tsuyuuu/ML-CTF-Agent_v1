#!/usr/bin/env bash
set -euo pipefail
BUNDLE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO="${1:-/workspaces/ML-CTF-Agent_v1}"
if [[ ! -d "$REPO/.git" ]]; then
    echo "Not a git checkout: $REPO" >&2
    exit 1
fi
python3 "$BUNDLE_DIR/patch_phase2.py" "$REPO"
cd "$REPO"
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest -v test_specialist_tools
python3 -m compileall -q controller.py agent_core.py ctf_specialist_tools.py ctf_runtime_config.py benchmark_runner.py challenge_runner.py run_dev.py

git diff --check
cat <<'EOF'

Phase 2 is applied locally; NOTHING was pushed to GitHub.
Review: git status --short; git diff -- controller.py tools.json agent_core.py

Set extra DEVELOPMENT budget as needed (caps remain enforced):
  export CTF_SOLVER_IMAGE=ctf-solver:tools-v1
  export CTF_MAX_STEPS=40
  export CTF_MAX_SECONDS=900

Offline tool tests:
  python3 -m unittest -v test_specialist_tools

To test against the real solver container, see README_PHASE2.md.
EOF
