# Phase 2: CTF specialist tools and configurable attempt limits

Prepared against the `tsuyuuu/ml-ctf-agent` project source inspected on November 15, 2026. The actual Codespaces folder in this project is `/workspaces/ML-CTF-Agent_v1`.

## What changes

- `list_files(root)` discovers authorized contestant files without requiring the model to handcraft find commands.
- `run_python(code)` executes up to 2,700 UTF-8 bytes of Python **inside the existing Docker solver**, with bounded stdout/stderr and timeouts; an isolated solver cannot read benchmark flags.
- `analyze_artifact(path, mode)` provides bounded file type/SHA256/EXIF, hex, strings, and archive listing for forensic/miscellaneous files. No extraction or system-level code execution happens in the controller.
- `tools.json` exposes those tools to the Ollama tool-calling interface; `controller.py` routes them to the correct bounded implementations.
- `agent_core.py` gets short category-aware tool guidance.
- `CTF_MAX_STEPS` and `CTF_MAX_SECONDS` allow development experiments without changing the old defaults of 15 and 300; controllers enforce hard maximum values of 100 and 3600.
- `run_dev.py` now includes the new tools in its filtered set.

The upgrade **does not** modify the verifier, Docker security configuration, evaluation outputs, model provider, or original challenge datasets. It does not add web connectivity or service startup for web/pwn challenges. It does not make the agent able to solve all categories automatically.

## Apply on Codespaces

Copy the extracted Phase 2 folder to your workspace (e.g. under `/workspaces/`), then run:

```bash
bash /workspaces/ctf-agent-phase2/apply_phase2.sh /workspaces/ML-CTF-Agent_v1
```

This patches only the inspected source layouts. If a teammate has changed the same code, the patch refuses rather than guessing. Review the changes and run tests before committing to your branch.

## Development settings

```bash
cd /workspaces/ML-CTF-Agent_v1
export CTF_SOLVER_IMAGE=ctf-solver:tools-v1
export CTF_MAX_STEPS=40
export CTF_MAX_SECONDS=900
python3 -m unittest -v test_specialist_tools
```

`CTF_MAX_STEPS` controls the number of tool calls, not a Claude thinking-token allowance or a cloud billing quota. Keeping a hard wall-clock deadline is required for safe autonomous attempts. Choose the caps appropriate to any competition rules.

## Test the real Docker integration (no model or flag access)

```bash
python3 - <<'PY'
from solver_runtime import DockerSolver
from controller import ToolDispatcher

solver = DockerSolver()
try:
    solver.start()
    dispatcher = ToolDispatcher(solver)
    print(dispatcher('run_python', {
        'code': 'from Crypto.Util.number import long_to_bytes\n'
                'print(long_to_bytes(0x464c4147).decode())'
    }))
    print(dispatcher('list_files', {'root': '/work'}))
    print(dispatcher('run_python', {
        'code': 'import pwn, sympy, z3\nprint("LIBRARIES_OK")'
    }))
finally:
    solver.stop()
PY
```

For `analyze_artifact`, stage an innocuous file as a contestant file and mount it via `solver.start(challenge_dir=...)`; do **not** mount the whole benchmark directory. An agent test with a model requires `OLLAMA_API_KEY`; keep that private and run only on permitted development challenges.

## Claude migration (next phase)

Do not swap `OLLAMA_API_KEY` for `ANTHROPIC_API_KEY` in the existing code: Anthropic Messages API uses a different request shape (`system`, `messages`, `max_tokens`, tools with `input_schema`) and returns `tool_use` blocks identified by ID. The controller must send each `tool_result` back under its matching `tool_use_id`. Add a separate model adapter and test it with mock tool results before attempting live competition challenges. Official documentation: https://platform.claude.com/docs/en/agents-and-tools/tool-use/handle-tool-calls

## AI acknowledgement

Code scaffolding and tests were generated with AI assistance and should be code-reviewed and disclosed according to the course policy.
